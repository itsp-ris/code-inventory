source("tree.wrappers.R.txt")
library(kknn)
library(tree)

#Question 2
#2.1a
ms.train <- read.csv("ms.train.csv", header = TRUE)
ms.test <- read.csv("ms.test.csv", header = TRUE)
knn = train.kknn(intensity ~ ., data = ms.train, 
                 kmax=25, kernel = "rectangular")
plot(knn, main = "Mean Squared Errors against k = 1...25")
#2.1b
y.test.hat.2 = fitted(kknn(intensity ~ ., ms.train, ms.test, 
                          kernel = knn$best.parameters$kernel, 
                          k = 2))
y.test.hat.5 = fitted(kknn(intensity ~ ., ms.train, ms.test, 
                           kernel = knn$best.parameters$kernel, 
                           k = 5))
y.test.hat.10 = fitted(kknn(intensity ~ ., ms.train, ms.test, 
                           kernel = knn$best.parameters$kernel, 
                           k = 10))
y.test.hat.20 = fitted(kknn(intensity ~ ., ms.train, ms.test, 
                           kernel = knn$best.parameters$kernel, 
                           k = 20))

plot(ms.train$MZ, ms.train$intensity, main = "k = 2")
points(ms.test$MZ, ms.test$intensity, col="blue")
points(ms.test$MZ, y.test.hat.2, col="green")
legend("topright", c("ms.train$intensity", "ms.test$intensity",
                     "estimated spectrum"), 
       fill = c("black", "blue", "green")) 

plot(ms.train$MZ, ms.train$intensity, main = "k = 5")
points(ms.test$MZ, ms.test$intensity, col="blue")
points(ms.test$MZ, y.test.hat.5, col="green")
legend("topright", c("ms.train$intensity", "ms.test$intensity",
                     "estimated spectrum"), 
       fill = c("black", "blue", "green")) 

plot(ms.train$MZ, ms.train$intensity, main = "k = 10")
points(ms.test$MZ, ms.test$intensity, col="blue")
points(ms.test$MZ, y.test.hat.10, col="green")
legend("topright", c("ms.train$intensity", "ms.test$intensity",
                     "estimated spectrum"), 
       fill = c("black", "blue", "green")) 

plot(ms.train$MZ, ms.train$intensity, main = "k = 20")
points(ms.test$MZ, ms.test$intensity, col="blue")
points(ms.test$MZ, y.test.hat.20, col="green")
legend("topright", c("ms.train$intensity", "ms.test$intensity",
                     "estimated spectrum"), 
       fill = c("black", "blue", "green")) 
#2.2
print(knn$best.parameters$k)
#2.4
tree.train = tree(intensity ~ ., ms.train, 
                  control = tree.control(nobs = 200, 
                                         mindev = 1e-5))
cv = learn.tree.cv(tree.train, nfolds = 10, m = 1000)
pred = predict(cv$best.tree, ms.test)
plot(ms.train$MZ, ms.train$intensity)
points(ms.test$MZ, ms.test$intensity, col="blue")
points(ms.test$MZ, pred, col="green")
legend("topright", c("ms.train$intensity", "ms.test$intensity",
                     "predicted intensity"), 
       fill = c("black", "blue", "green")) 
