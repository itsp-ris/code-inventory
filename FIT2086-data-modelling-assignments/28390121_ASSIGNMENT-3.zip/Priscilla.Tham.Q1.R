source("tree.wrappers.R.txt")
source("my.prediction.stats.R.txt")
library(tree)
library(boot)

#Question 1
#1.1
heart <- read.csv("heart.csv", header = TRUE)
tree.heart = tree(HD ~ ., heart)
cv = learn.tree.cv(tree.heart, nfolds = 10, m = 1000)
summary(cv$best.tree)
#1.2
plot(cv$best.tree)
text(cv$best.tree, pretty = 12)
#1.3
tree.heart
#1.5
fullmod = glm(HD ~ ., data = heart, family=binomial)
step.fit.bic = step(fullmod, k = log(nrow(heart)), 
                    direction = "both", trace = 0)
summary(step.fit.bic)
#1.7
prob.BIC = predict(fullmod, heart, type = "response")
prob.tree = predict(cv$best.tree, heart)
my.pred.stats(prob.BIC, heart$HD)
my.pred.stats(prob.tree[,2], heart$HD)
#1.8
d = data.frame(AGE = c(55), SEX = c("M"), 
                  CP = c("Atypical"), TRESTBPS = c(140), 
                  CHOL = c(217), FBS = c(">120"), 
                  RESTECG = c("Normal"), THALACH = c(111), 
                  EXANG = c("Y"), OLDPEAK = c(5.6), 
                  SLOPE = c("Flat"), CA = c(1), 
                  THAL = c("Reversible.Defect"))
summary(predict(cv$best.tree, d))
summary(predict(step.fit.bic, d, 
                  type = "response"))
#1.9
boot.auc = function(formula, data, indices) {
  df = data.frame(AGE = c(55), SEX = c("M"), 
                  CP = c("Atypical"), TRESTBPS = c(140), 
                  CHOL = c(217), FBS = c(">120"), 
                  RESTECG = c("Normal"), THALACH = c(111), 
                  EXANG = c("Y"), OLDPEAK = c(5.6), 
                  SLOPE = c("Flat"), CA = c(1), 
                  THAL = c("Reversible.Defect"))
  d = data[indices, ]
  fit = glm(formula, d, family = binomial)
  rv = predict(fit, df, type = "response")
  return(rv/(1-rv))
}
bs = boot(data = heart, statistic = boot.auc, 
          R = 5000, formula = HD ~ .)
boot.ci(bs,conf = 0.95,type = "bca")
